func getFibonacciSubarray(startingNumber: Int, count: Int) -> [Int] {
    var fibonacciSequence = [Int]()
    var currentNumber = 0
    var nextNumber = 1
    
//    Keep looping to generate the fib sequence starting from startingNum and populate the array until count is reached
    while fibonacciSequence.count < count {
//        We calculate the nextnumber in the sequence by adding the current and the next
        let temp = nextNumber
        nextNumber = currentNumber + nextNumber
        currentNumber = temp
        
        if currentNumber >= startingNumber {
            fibonacciSequence.append(currentNumber)
        }
    }
    
//    If they aren't equal then starting number is not part of the sequence.
//    If they are, then it is part of the sequence
    if fibonacciSequence.first != startingNumber {
        return []
    }
    
    return fibonacciSequence
}


let subarray1 = getFibonacciSubarray(startingNumber: 3, count: 2)
print(subarray1) // Output: [3, 5]

let subarray2 = getFibonacciSubarray(startingNumber: 5, count: 3)
print(subarray2) // Output: [5, 8, 13]

let subarray3 = getFibonacciSubarray(startingNumber: 4, count: 4)
print(subarray3) // Output: []
